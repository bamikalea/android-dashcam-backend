package com.alibaba.sdk.android.mns.model.result;

import com.alibaba.sdk.android.mns.model.MNSResult;

/**
 * Created by pan.zengp on 2016/7/30.
 */
public class DeleteQueueResult extends MNSResult {
}

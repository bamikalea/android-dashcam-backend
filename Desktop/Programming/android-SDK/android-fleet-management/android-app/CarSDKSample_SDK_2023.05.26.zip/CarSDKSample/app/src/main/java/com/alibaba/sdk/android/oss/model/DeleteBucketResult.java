package com.alibaba.sdk.android.oss.model;

/**
 * Created by LK on 15/12/15.
 */
public class DeleteBucketResult extends OSSResult {

}

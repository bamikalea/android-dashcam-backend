package com.alibaba.sdk.android.common.auth;

/**
 * Created by zhouzhuo on 11/4/15.
 */
public abstract class CredentialProvider {
}

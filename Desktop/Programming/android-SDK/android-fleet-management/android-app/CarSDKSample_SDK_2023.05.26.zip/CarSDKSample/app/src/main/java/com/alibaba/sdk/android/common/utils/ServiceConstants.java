/**
 * Copyright (C) Alibaba Cloud Computing, 2015
 * All rights reserved.
 * 
 * 版权所有 （C）阿里巴巴云计算，2015
 */

package com.alibaba.sdk.android.common.utils;

public interface ServiceConstants {

    public static final String DEFAULT_ENCODING = "utf-8";

    public static final String RESOURCE_NAME_COMMON = "common";
}
